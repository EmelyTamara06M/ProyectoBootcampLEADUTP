import os
from flask import Flask
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient

app = Flask(__name__)

# La URL de tu Key Vault
KEY_VAULT_URI = "https://kvproyectobootcamp.vault.azure.net/"

@app.route('/')
def index():
    try:
        # 1. Autenticarse usando la Identidad Administrada de tu Web App
        credential = DefaultAzureCredential()
        
        # 2. Conectarse a tu Key Vault
        client = SecretClient(vault_url=KEY_VAULT_URI, credential=credential)
        
        # 3. Leer el secreto que creaste llamado "mensaje"
        secreto = client.get_secret("mensaje")
        
        # 4. Mostrar el valor del secreto en la pantalla
        return f"<h1>¡Éxito! El secreto es: {secreto.value}</h1>"
        
    except Exception as e:
        return f"Hubo un error al intentar leer el secreto: {e}"

if __name__ == '__main__':
    app.run()